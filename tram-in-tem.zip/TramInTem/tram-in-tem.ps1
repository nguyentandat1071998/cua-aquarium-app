# Tram in tem CUA - chay nen tren laptop cam may in don.
# Cu vai giay hoi may chu xem co lenh in van don (gui tu dien thoai) khong, co thi in thang ra may in.
$ErrorActionPreference = 'Stop'
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$log = Join-Path $dir 'tram-in-tem.log'
function Ghi($s) {
  try {
    if ((Test-Path $log) -and ((Get-Item $log).Length -gt 1MB)) { Remove-Item $log -Force }
    Add-Content -Path $log -Value ("{0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $s) -Encoding UTF8
  } catch {}
}
# Chi chay 1 ban
$mutex = New-Object System.Threading.Mutex($false, 'Global\CuaTramInTem')
if (-not $mutex.WaitOne(0)) { exit }

$cfg = Get-Content (Join-Path $dir 'cauhinh.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$W = 'https://cua-video-upload.nguyentandat1071998.workers.dev/'
$sumatra = Join-Path $dir 'SumatraPDF.exe'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$tmp = Join-Path $env:TEMP 'cua-tram-in-tem'
New-Item -ItemType Directory -Force -Path $tmp | Out-Null

function Goi($action, $body) {
  $h = @{ 'x-action' = $action; 'x-api-key' = $cfg.khoa; 'x-may-in' = [uri]::EscapeDataString($cfg.mayIn) }
  $json = $body | ConvertTo-Json -Compress -Depth 5
  Invoke-RestMethod -Uri $W -Method Post -Headers $h -ContentType 'application/json; charset=utf-8' -Body ([Text.Encoding]::UTF8.GetBytes($json)) -TimeoutSec 40
}

Ghi "Bat dau - may in: $($cfg.mayIn)"
while ($true) {
  try {
    $kq = Goi 'lay-lenh-in-tem' @{}
    foreach ($l in @($kq.lenh)) {
      if (-not $l) { continue }
      $loi = ''
      try {
        $files = @()
        $i = 0
        foreach ($u in @($l.links)) {
          if (-not $u) { continue }
          $i++
          $f = Join-Path $tmp ("{0}_{1}.pdf" -f $l.id, $i)
          Invoke-WebRequest -Uri $u -OutFile $f -UseBasicParsing -TimeoutSec 90
          $dau = [IO.File]::ReadAllBytes($f) | Select-Object -First 4
          if (([Text.Encoding]::ASCII.GetString($dau)) -ne '%PDF') { throw 'File van don khong hop le (link co the da het han 10 phut) - bam In van don lai tren app' }
          $files += $f
        }
        if ($l.anh) {
          $f = Join-Path $tmp ("{0}_anh.png" -f $l.id)
          [IO.File]::WriteAllBytes($f, [Convert]::FromBase64String($l.anh.Substring($l.anh.IndexOf(',') + 1)))
          $files += $f
        }
        if (-not $files.Count) { throw 'Lenh in khong co file' }
        foreach ($f in $files) {
          $p = Start-Process -FilePath $sumatra -ArgumentList @('-print-to', ('"{0}"' -f $cfg.mayIn), '-print-settings', 'fit', '-silent', ('"{0}"' -f $f)) -Wait -PassThru -WindowStyle Hidden
          if ($p.ExitCode -ne 0) { throw ("May in bao loi (ma {0}) - kiem tra may in da bat, con giay" -f $p.ExitCode) }
        }
        Ghi ("Da in lenh {0}: {1} file - don {2}" -f $l.id, $files.Count, (@($l.maDon) -join ', '))
      } catch {
        $loi = $_.Exception.Message
        Ghi ("LOI lenh {0}: {1}" -f $l.id, $loi)
      }
      try { Goi 'bao-da-in-tem' @{ id = $l.id; loi = $loi } | Out-Null } catch { Ghi ("Khong bao duoc ket qua: " + $_.Exception.Message) }
      Get-ChildItem $tmp -Filter ("{0}_*" -f $l.id) -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
    }
  } catch {
    Ghi ("Mat ket noi: " + $_.Exception.Message)
    Start-Sleep -Seconds 10
  }
  Start-Sleep -Seconds 3
}
