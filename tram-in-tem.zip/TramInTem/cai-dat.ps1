# Cai dat Tram in tem CUA
$ErrorActionPreference = 'Stop'
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Write-Host '=== CAI DAT TRAM IN TEM CUA ===' -ForegroundColor Green
Write-Host ''

# 1. SumatraPDF (phan mem doc PDF mien phi, dung de in thang khong hien hop thoai)
$sumatra = Join-Path $dir 'SumatraPDF.exe'
if (-not (Test-Path $sumatra)) {
  Write-Host 'Dang tai SumatraPDF tu trang chinh thuc sumatrapdfreader.org ...'
  $zip = Join-Path $env:TEMP 'SumatraPDF.zip'
  Invoke-WebRequest -Uri 'https://www.sumatrapdfreader.org/dl/rel/3.6.1/SumatraPDF-3.6.1-64.zip' -OutFile $zip -UseBasicParsing
  $ra = Join-Path $env:TEMP 'SumatraPDF_giai_nen'
  if (Test-Path $ra) { Remove-Item $ra -Recurse -Force }
  Expand-Archive -Path $zip -DestinationPath $ra -Force
  $exe = Get-ChildItem $ra -Filter 'SumatraPDF*.exe' -Recurse | Select-Object -First 1
  if (-not $exe) { throw 'Khong tim thay SumatraPDF trong file tai ve' }
  Copy-Item $exe.FullName $sumatra -Force
  Write-Host 'Da tai xong SumatraPDF.' -ForegroundColor Green
}

# 2. Chon may in don
Write-Host ''
Write-Host 'Cac may in tren may nay:'
$ds = @(Get-Printer | Select-Object -ExpandProperty Name)
for ($i = 0; $i -lt $ds.Count; $i++) { Write-Host ("  {0}. {1}" -f ($i + 1), $ds[$i]) }
$so = Read-Host 'Nhap SO THU TU cua may in DON (may in tem van don)'
$mayIn = $ds[[int]$so - 1]
if (-not $mayIn) { throw 'So thu tu khong dung' }

# 3. Ma khoa
Write-Host ''
Write-Host 'Mo app CUA tren dien thoai/may tinh: Thiet lap > He thong > Tram in tem > Tao ma khoa.'
$khoa = (Read-Host 'Dan MA KHOA tram in tem vao day').Trim()
if (-not $khoa.StartsWith('tem-')) { throw 'Ma khoa phai bat dau bang tem-' }

@{ mayIn = $mayIn; khoa = $khoa } | ConvertTo-Json | Set-Content -Path (Join-Path $dir 'cauhinh.json') -Encoding UTF8

# 4. Tu chay khi mo may
$startup = [Environment]::GetFolderPath('Startup')
$lnk = Join-Path $startup 'Tram in tem CUA.lnk'
$ws = New-Object -ComObject WScript.Shell
$sc = $ws.CreateShortcut($lnk)
$sc.TargetPath = (Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe')
$sc.Arguments = ('-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "{0}"' -f (Join-Path $dir 'tram-in-tem.ps1'))
$sc.WorkingDirectory = $dir
$sc.WindowStyle = 7
$sc.Save()

# 5. Chay ngay
Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -like '*tram-in-tem.ps1*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Start-Process -FilePath $sc.TargetPath -ArgumentList $sc.Arguments -WorkingDirectory $dir -WindowStyle Hidden
Write-Host ''
Write-Host ("XONG. Tram in tem dang chay voi may in: {0}" -f $mayIn) -ForegroundColor Green
Write-Host 'Tu gio moi lan mo laptop no tu chay ngam. Nhat ky: tram-in-tem.log trong thu muc nay.'
